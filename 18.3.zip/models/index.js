const Pizza = require('./Pizza');
const Comment = require('./Comment');

module.exports = { Pizza, Comment };
