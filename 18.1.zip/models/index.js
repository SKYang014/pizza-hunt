const Pizza = require('./Pizza');

module.exports = { Pizza };
